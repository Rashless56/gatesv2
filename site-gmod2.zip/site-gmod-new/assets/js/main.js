// =============================================
//  GATES ZONE-74 — MAIN JS
// =============================================

// ─── CAROUSEL ───────────────────────────────
const ADDON_COUNT = 80;
const IMGS_PER_SLIDE = 3;
const slides = [];

for (let i = 0; i < ADDON_COUNT; i += IMGS_PER_SLIDE) {
  slides.push([i + 1, i + 2, i + 3].filter(n => n <= ADDON_COUNT));
}

const track = document.getElementById('carouselTrack');
const dotsContainer = document.getElementById('carouselDots');
let current = 0;
let autoTimer;

if (track) {
  // Build slides
  slides.forEach((group, idx) => {
    const slide = document.createElement('div');
    slide.className = 'carousel-slide';
    group.forEach(n => {
      const img = document.createElement('img');
      img.src = `addons-images/addon${n}.png`;
      img.alt = `Addon ${n}`;
      img.loading = 'lazy';
      slide.appendChild(img);
    });
    track.appendChild(slide);
  });

  // Build dots
  slides.forEach((_, idx) => {
    const btn = document.createElement('button');
    btn.addEventListener('click', () => goTo(idx));
    dotsContainer.appendChild(btn);
  });

  function goTo(n) {
    current = (n + slides.length) % slides.length;
    track.style.transform = `translateX(-${current * 100}%)`;
    Array.from(dotsContainer.children).forEach((d, i) => d.classList.toggle('active', i === current));
  }

  function startAuto() { autoTimer = setInterval(() => goTo(current + 1), 3500); }
  function stopAuto()  { clearInterval(autoTimer); }

  goTo(0);
  startAuto();

  document.getElementById('prevBtn')?.addEventListener('click', () => { stopAuto(); goTo(current - 1); startAuto(); });
  document.getElementById('nextBtn')?.addEventListener('click', () => { stopAuto(); goTo(current + 1); startAuto(); });
}

// ─── MOBILE NAV ─────────────────────────────
const navToggle = document.getElementById('navToggle');
const mainNav   = document.getElementById('mainNav');

navToggle?.addEventListener('click', () => {
  mainNav.classList.toggle('open');
});

// Close nav on outside click
document.addEventListener('click', e => {
  if (!mainNav?.contains(e.target) && !navToggle?.contains(e.target)) {
    mainNav?.classList.remove('open');
  }
});

// ─── ACTIVE NAV LINK ────────────────────────
const page = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-link').forEach(a => {
  if (a.getAttribute('href') === page) a.classList.add('active');
  else a.classList.remove('active');
});

// ─── SCROLL REVEAL (simple) ─────────────────
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
      observer.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.dept-card').forEach(card => {
  card.style.opacity = '0';
  card.style.transform = 'translateY(20px)';
  card.style.transition = 'opacity 0.5s ease, transform 0.5s ease, border-color 0.25s, box-shadow 0.25s';
  observer.observe(card);
});
